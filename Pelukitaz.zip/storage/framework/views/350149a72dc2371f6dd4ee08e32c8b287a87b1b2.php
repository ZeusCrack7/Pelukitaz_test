

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 5px">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="col-lg-12">
                <div class="text">-</div>
                <div class="d-flex justify-content-between mt-3">
                    <hr>
                    <h4>Inventario de productos</h4>
                    <h4>Agregar nuevo(s) producto(s)<a href="<?php echo e(route('products.create')); ?>" class="ml-2 btn btn-success btn-sm"><i class="bi bi-plus-circle fs-6"></i></a></h4>
                    <h4>Inserte filtro aquí</h4>
                </div>
            </div>
            <hr>
            <ul class="list-group">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($pro->category_id !== 1): ?>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-lg-3">
                            <img src="/images/<?php echo e($pro->image_path); ?>"
                                class="card-img-top mx-auto"
                                style="height: 80px; width: 80px;display: block;"
                                alt="<?php echo e($pro->image_path); ?>"
                            >
                        </div>
                        <div class="col-lg-6">
                            <h6 class="card-title mb-2"><?php echo e($pro->name); ?></h6>
                            <p>Precio de compra: $<?php echo e($pro->sell_price); ?></p>
                            <p>Precio de venta: $<?php echo e($pro->price); ?></p>
                            <p>Stock: <?php echo e($pro->stock); ?></p>
                            <p>Utilidad: <?php echo e($pro->utilidades); ?></p>
                            <p>Sucursal: <?php echo e($pro->id_sucursal == 1 ? 'Guadalupe ' : 'Zacatecas'); ?></p>
                        </div>
                        <div class="col-lg-3">
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($pro->id); ?>" id="id" name="id" >
                                <input type="hidden" value="<?php echo e($pro->name); ?>" id="name" name="name">
                                <input type="hidden" value="<?php echo e($pro->sell_price); ?>" id="price" name="price">
                                <input type="hidden" value="<?php echo e($pro->image_path); ?>" id="img" name="img">
                                <input type="hidden" value="<?php echo e($pro->slug); ?>" id="slug" name="slug">
                                <input type="hidden" value="1" id="quantity" name="quantity">
                            </form>
                            <form action="<?php echo e(route('products.destroy', $pro->id)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-danger btn-sm" style="margin-right: 10px;"><i class="fa fa-trash"></i></button>
                            </form>
                            <a href="<?php echo e(route('products.edit', $pro->id)); ?>" class="btn btn-warning btn-sm mt-2"><i class="fa fa-edit"></i></a>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-lg-2">
                            <form action="<?php echo e(route('inventory.store')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($pro->id); ?>" name="product_id">
                                <input type="number" class="form-control form-control-s" name="quantity" placeholder="Agregar inventario">
                                <button type="submit" class="btn btn-success btn-sm"><i class="bi bi-plus-circle fs-6"></i></button>
                            </form>
                        </div>
                    </div>
                </li>
                <hr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\xampp\Pelukitaz_test\resources\views/stock.blade.php ENDPATH**/ ?>