

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Editar producto</h2>
    <form method="POST" action="<?php echo e(route('products.update', $product->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="name">Nombre:</label>
            <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control">
        </div>
        
        <div class="form-group">
            <label for="sell_price">Precio de compra:</label>
            <input type="number" name="sell_price" value="<?php echo e($product->sell_price); ?>" class="form-control">
        </div>
        
        <div class="form-group">
            <label for="price">Precio de venta:</label>
            <input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control">
        </div>
        
        <button type="submit" class="btn btn-dark ml-5">Actualizar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\xampp\Pelukitaz_test\resources\views/edit.blade.php ENDPATH**/ ?>